package com.tracker.tests;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.ict.learnertracker.PlacementLogin;
import com.ict.learnertracker.TrainerLogin;

public class TrackerTest1 extends TrackerBaseTest {

    TrainerLogin trnobj;
    PlacementLogin pcnobj;

    @Test(priority=1)
    public void TC_HP_001() {
        trnobj = new TrainerLogin(driver);
        System.out.println("Navigated to homepage");
       
    }

    @Test(priority=2)
    public void TC_LT_002() throws InterruptedException {
        trnobj = new TrainerLogin(driver);
        trnobj.login("trainer", "trainer@123");
        trnobj.LearnerAdd();
        System.out.println("Navigated to Learner's Form");
        trnobj.addLearner("ict45", "Dev", "FSD", "KKEM", "May_22", "Qualified");
        System.out.println("Alert accepted");
        String act="Individual learner added";
        String exp=act;
        AssertJUnit.assertEquals(act,exp);
    }

    @Test(priority=3)
    public void TC_BD_003() throws InterruptedException {
        trnobj = new TrainerLogin(driver);
        trnobj.addButton();
        String csvFilePath = "F:\\ICTTechblog\\src\\main\\resources\\csv\\SampleCSV - Sheet1.csv";
        trnobj.addBulkLearners(csvFilePath);
        trnobj.TrainerClick();
        trnobj.Logout();
        String act="Trainer successfully added";
        String exp=act;
        AssertJUnit.assertEquals(act,exp);
    }

    @Test(priority=4)
    public void TC_HO_004() {
        pcnobj = new PlacementLogin(driver);
        System.out.println("Navigated to homepage");
        String act="Navigate to homepage";
        String exp=act;
        AssertJUnit.assertEquals(act,exp);
    }

    @Test(priority=5)
    public void TC_LP_005() throws InterruptedException {
        pcnobj = new PlacementLogin(driver);
        pcnobj.login("pofficer", "pofficer@123");
        pcnobj.update();
        pcnobj.updatePlacementStatus("Job seeking");
        pcnobj.submit();
        pcnobj.officerclick();
        pcnobj.logout();
        String act="Officer Successfully changed in status";
        String exp=act;
        AssertJUnit.assertEquals(act,exp);
        driver.quit();
    }

	
}
