package com.ict.learnertracker;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class TrainerLogin {

    WebDriver driver;

    @FindBy(xpath = "//input[@id='username']")
    private WebElement UserName;
    @FindBy(xpath = "//input[@id='password']")
    private WebElement Password;
    @FindBy(xpath = "//button[normalize-space()='Login']")
    private WebElement Login1;
    @FindBy(xpath = "//ion-icon[@name='person-add-outline']")
    public WebElement LearnerAdd;
    @FindBy(xpath = "//input[@id='learnerid']")
    private WebElement LearnerID;
    @FindBy(xpath = "//input[@id='name']")
    private WebElement LearnerName;
    @FindBy(xpath = "//select[@name='course']")
    public WebElement CourseClick;
    @FindBy(xpath = "//option[@value='FSD']")
    public WebElement Course;
    @FindBy(xpath = "//select[@name='project']")
    private WebElement Project;
    @FindBy(xpath = "//select[@name='batch']")
    private WebElement Batch;
    @FindBy(xpath = "//select[@name='cstatus']")
    private WebElement CourseStatus;
    @FindBy(xpath = "//button[normalize-space()='Submit']")
    private WebElement Submit;
    @FindBy(xpath="//button[normalize-space()='OK']")
    private WebElement Alert;
    @FindBy(xpath = "//ion-icon[@name='cloud-upload']")
    private WebElement addButton;
    @FindBy(xpath = "//input[@name='file']")
    private WebElement csvFileInput;
    @FindBy(xpath = "//button[normalize-space()='Submit']")
    private WebElement submitButton;
    @FindBy(xpath= " //button[normalize-space()='Return to Dashboard']")
    private WebElement handleAlert;
    @FindBy(xpath= " //button[normalize-space()='OK']")
    private WebElement Saved;
    @FindBy(xpath="//a[@id='basic-nav-dropdown']")
    private WebElement TrainerClick;
    @FindBy(xpath = "//a[normalize-space()='Logout']")
    private WebElement Logout;
    
    
    


    

    
    

     

    public TrainerLogin(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void login(String username, String password) {
        UserName.sendKeys(username);
        Password.sendKeys(password);
        Login1.click();
    }

    
    public void LearnerAdd() {
		
	}
    public void addLearner(String learnerID, String learnerName, String course, String project, String batch, String courseStatus) {
        LearnerAdd.click();
        LearnerID.sendKeys(learnerID);
        LearnerName.sendKeys(learnerName);
        selectDropdownOption(CourseClick, course);
        selectDropdownOption(Project, project);
        selectDropdownOption(Batch, batch);
        selectDropdownOption(CourseStatus, courseStatus);
        Submit.click();
        Alert.click();
    }
	

    private void selectDropdownOption(WebElement dropdown, String option) {
        Select select = new Select(dropdown);
        select.selectByVisibleText(option);
    }
    public void addBulkLearners(String csvFilePath) {
        addButton.click();
        csvFileInput.sendKeys(csvFilePath);
        submitButton.click();
        handleAlert.click();
        Saved.click();
        TrainerClick.click();
        Logout.click();
    }

	public void addButton() {
		// TODO Auto-generated method stub
		
	}

	public void Logout() {
		// TODO Auto-generated method stub
		
	}
	public void TrainerClick() {

    
    
	}

	public boolean isLoggedOut() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean isLearnerAddedSuccessfully() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean isOnHomePage() {
		// TODO Auto-generated method stub
		return false;
	}
}




