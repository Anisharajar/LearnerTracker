package com.ict.learnertracker;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PlacementLogin {

    WebDriver driver;

    @FindBy(xpath = "//input[@id='username']")
    private WebElement UserName;
    @FindBy(xpath = "//input[@id='password']")
    private WebElement Password;
    @FindBy(xpath = "//button[normalize-space()='Login']")
    private WebElement LoginButton;
    @FindBy(xpath = "//tbody/tr[1]/td[8]/button[1]")
    private WebElement Update;
    @FindBy(xpath = "//select[@name='pstatus']")
   private WebElement PlacementStatusDropdown;
    
    @FindBy(xpath = "//button[normalize-space()='Submit']")
    private WebElement SubmitButton;
    @FindBy(xpath="//a[@id='basic-nav-dropdown']")
    private WebElement TrainerClick;
    @FindBy(xpath = "//a[normalize-space()='Logout']")
    private WebElement Logout;

    public PlacementLogin(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        
    }

    public void login(String username, String password) {
        UserName.sendKeys(username);
        Password.sendKeys(password);
        LoginButton.click();
    }

    public void updatePlacementStatus(String status) {
//        selectPlacementStatus(status);
        Update.click();
        handleAlert();
        TrainerClick.click();
        Logout.click();
    }

  private void selectPlacementStatus(String status) {
       Select select = new Select(PlacementStatusDropdown);
       select.selectByVisibleText(status);
   }

    private void handleAlert() {
        SubmitButton.click();
    }

	public void Update() {
		
	}

	

	public void login() {
		// TODO Auto-generated method stub
		
	}

	public void update() {
		// TODO Auto-generated method stub
		
	}

	public void submit() {
		// TODO Auto-generated method stub
		
	}

	public void logout() {
		// TODO Auto-generated method stub
		
	}

	public void officerclick() {
		// TODO Auto-generated method stub
		
	}

	

    
}